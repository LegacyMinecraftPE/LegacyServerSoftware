package org.itxtech.nemisys.event.server;

import org.itxtech.nemisys.event.Event;

/**
 * author: MagicDroidX
 * Nukkit Project
 */
abstract public class ServerEvent extends Event {
}
