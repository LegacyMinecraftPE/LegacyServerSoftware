package org.itxtech.nemisys.plugin.certification;

import org.itxtech.nemisys.plugin.PluginBase;

/**
 * Created by iNevet
 */
public class PluginCertificateTask {

    private final PluginBase plugin;

    public PluginCertificateTask(PluginBase plugin) {
        this.plugin = plugin;
    }

    public boolean run() {
        return false;
    }

}
