## PocketMine-MP for Android

Read the license :)
