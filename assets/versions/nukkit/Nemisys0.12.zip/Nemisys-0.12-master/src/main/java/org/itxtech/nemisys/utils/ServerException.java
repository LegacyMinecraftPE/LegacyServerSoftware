package org.itxtech.nemisys.utils;

/**
 * author: MagicDroidX
 * Nukkit Project
 */
public class ServerException extends RuntimeException {
    public ServerException(String message) {
        super(message);
    }
}
