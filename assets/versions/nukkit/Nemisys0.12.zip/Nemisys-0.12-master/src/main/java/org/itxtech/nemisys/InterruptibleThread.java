package org.itxtech.nemisys;

public interface InterruptibleThread {
}
