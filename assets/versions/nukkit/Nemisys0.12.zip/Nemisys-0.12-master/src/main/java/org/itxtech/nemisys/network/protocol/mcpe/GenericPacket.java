package org.itxtech.nemisys.network.protocol.mcpe;

/**
 * Author: PeratX
 * Nemisys Project
 */
public class GenericPacket extends DataPacket{
    @Override
    public byte pid() {
        return 0;
    }

    @Override
    public void encode() {

    }

    @Override
    public void decode() {

    }
}
