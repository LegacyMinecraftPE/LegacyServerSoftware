# PocketMine-MP 1.5dev-1438 fork by Fölix Team
Supported versions: 0.11.0-0.11.1 *& prob some builds*

Features:

• All mobs and eggs

• All blocks *(will be soon)*

• Some vanilla features what was not added

• *and some other bug fixes...*

**Discord: https://discord.gg/b2H4qnZPCm**

*wonder will someone read it?*
