#!/bin/bash
php server.php &
cat>console.in