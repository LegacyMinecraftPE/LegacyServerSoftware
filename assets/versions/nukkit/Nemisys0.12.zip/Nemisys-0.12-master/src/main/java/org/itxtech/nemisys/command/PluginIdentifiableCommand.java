package org.itxtech.nemisys.command;

import org.itxtech.nemisys.plugin.Plugin;

/**
 * author: MagicDroidX
 * Nukkit Project
 */
public interface PluginIdentifiableCommand {

    Plugin getPlugin();
}
