package org.itxtech.nemisys.utils;

/**
 * author: MagicDroidX
 * Nukkit Project
 */
public class EventException extends ServerException {
    public EventException(String message) {
        super(message);
    }
}
