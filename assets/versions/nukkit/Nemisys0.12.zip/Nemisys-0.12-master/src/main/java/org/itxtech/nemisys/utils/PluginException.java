package org.itxtech.nemisys.utils;

/**
 * author: MagicDroidX
 * Nukkit Project
 */
public class PluginException extends ServerException {
    public PluginException(String message) {
        super(message);
    }
}
