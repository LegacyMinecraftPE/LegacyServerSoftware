package org.itxtech.nemisys.utils;

/**
 * author: MagicDroidX
 * Nukkit Project
 */
public abstract class ThreadedLogger extends Thread implements Logger {
}
