#!/bin/bash
php PocketMine-MP.php &
cat > src/console.in